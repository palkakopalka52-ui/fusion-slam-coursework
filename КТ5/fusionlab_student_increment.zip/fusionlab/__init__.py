"""FusionLab teaching library."""
